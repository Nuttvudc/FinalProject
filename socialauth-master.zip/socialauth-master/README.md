# SocialAuth Facebook Login

Example of Facebook login and the graph api using the JavaScript SDK

### Version
1.0.0

## Usage
Add your app ID (https://developers.facebook.com/apps/)

Open index.html